const container = document.getElementById('container');
const car = document.getElementById('car');
const opponent1 = document.getElementById('opponent1');
const opponent2 = document.getElementById('opponent2');
const opponent3 = document.getElementById('opponent3');

let carPosition = 50;
let speed = 5;
let opponentSpeed = 2;
let obstacles = [];

function moveCar() {
    document.addEventListener('keydown', function(event) {
        if (event.key === 'ArrowUp' && carPosition > 0) {
            carPosition -= 10;
        }
        if (event.key === 'ArrowDown' && carPosition < 95) {
            carPosition += 10;
        }
    });
    car.style.bottom = carPosition + '%';
}

function moveOpponents() {
    document.addEventListener('keydown', function(event) {
        if (event.code === 'Space') {
            moveOpponent(opponent1);
            moveOpponent(opponent2);
            moveOpponent(opponent3);
        }
    });
}

function moveOpponent(opponent) {
    let opponentPosition = parseInt(opponent.style.bottom) || 0;
    opponentPosition += opponentSpeed;
    opponent.style.bottom = opponentPosition + '%';
    if (opponentPosition > 100) {
        opponent.style.bottom = '-10%';
    }
}

function createObstacle() {
    const obstacle = document.createElement('div');
    obstacle.classList.add('obstacle');
    obstacle.style.left = Math.random() * 90 + '%';
    container.appendChild(obstacle);
    obstacles.push(obstacle);
}

function moveObstacles() {
    obstacles.forEach(function(obstacle) {
        let obstacleTop = obstacle.offsetTop;
        obstacleTop += speed / 2;
        obstacle.style.top = obstacleTop + 'px';
        if (obstacleTop > 500) {
            obstacle.remove();
            obstacles.shift();
        }
    });
}

function checkCollision() {
    obstacles.forEach(function(obstacle) {
        if (carPosition > obstacle.offsetLeft - 50 && carPosition < obstacle.offsetLeft + 30 &&
            400 < obstacle.offsetTop + 30 && 400 > obstacle.offsetTop) {
            alert('Game Over!');
            location.reload();
        }
    });
}

function gameLoop() {
    moveCar();
    createObstacle();
    moveObstacles();
    moveOpponents();
    checkCollision();
    requestAnimationFrame(gameLoop);
}

gameLoop();
